# pylibwrite

A library that creates a requirements.txt file using only the libraries listed in the python file directly below it．